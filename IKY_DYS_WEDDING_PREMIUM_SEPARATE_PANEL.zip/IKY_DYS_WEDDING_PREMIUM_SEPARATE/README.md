# IKY & DYS Wedding Premium — Website dan Panel Terpisah

Paket ini memuat dua aplikasi Next.js yang memang dipisahkan:
- `website/`: website publik, halaman `/undangan/[slug]`, tema, Wedding Gift, galeri, musik, RSVP.
- `panel/`: Panel Master terpisah untuk membuat/edit undangan per pelanggan, mengatur tema, foto, musik, Wedding Gift, QRIS, RSVP, dan status publikasi.
- `shared/schema.sql`: skema database Neon bersama. Jalankan sekali di Neon SQL Editor.

## Tema yang tersedia
`chinese`, `luxury`, `minimalist`, `floral`, `traditional`.

## Deploy
1. Jalankan `shared/schema.sql` di Neon SQL Editor. SQL menggunakan `ADD COLUMN IF NOT EXISTS` untuk membantu tabel yang sudah ada; jangan menghapus tabel lama.
2. Deploy folder `website/` sebagai proyek Vercel pertama. Set environment variable `DATABASE_URL` dengan connection string Neon.
3. Deploy folder `panel/` sebagai proyek Vercel kedua. Set `DATABASE_URL` yang SAMA persis dan `ADMIN_PASSWORD` yang kuat.
4. Redeploy kedua proyek setelah menyimpan environment variables.
5. Buka domain Panel Master, login dengan `ADMIN_PASSWORD`, buat undangan, pilih tema, lalu centang Terbitkan.
6. Link publik berbentuk `https://DOMAIN-WEBSITE/undangan/slug-undangan`.

## Catatan penting
- Website dan panel sengaja menjadi dua deployment berbeda, tetapi berbagi database Neon yang sama.
- Jangan mengubah proyek KLAZ, Duniatopup, atau website utama `www.webkaryakita.com` saat men-deploy paket ini.
- Untuk URL gambar, gunakan URL gambar publik yang langsung bisa diakses. Untuk musik gunakan URL file audio yang bisa diakses langsung (misalnya MP3). QRIS hanya ditampilkan sebagai gambar; aplikasi ini tidak memverifikasi pembayaran hadiah.
- RSVP disimpan di tabel `wedding_rsvps`. Panel versi ini belum menampilkan daftar RSVP pada dashboard; tabel sudah disediakan untuk fitur lanjutan.
- Upload file langsung belum disediakan; panel memakai URL foto/musik/QRIS.
- Pastikan `ADMIN_PASSWORD` disetel dan rahasiakan `DATABASE_URL`.
