CREATE TABLE IF NOT EXISTS public.wedding_invitations (
 id BIGSERIAL PRIMARY KEY,
 slug TEXT NOT NULL UNIQUE,
 couple_one TEXT NOT NULL DEFAULT 'Mempelai 1',
 couple_two TEXT NOT NULL DEFAULT 'Mempelai 2',
 event_date TEXT NOT NULL DEFAULT '', event_time TEXT NOT NULL DEFAULT '',
 venue TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '',
 story TEXT NOT NULL DEFAULT '', hero_image TEXT NOT NULL DEFAULT '',
 gallery JSONB NOT NULL DEFAULT '[]'::jsonb,
 music_url TEXT NOT NULL DEFAULT '', theme TEXT NOT NULL DEFAULT 'luxury',
 published BOOLEAN NOT NULL DEFAULT FALSE,
 wedding_settings JSONB NOT NULL DEFAULT '{}'::jsonb,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS couple_one TEXT NOT NULL DEFAULT 'Mempelai 1';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS couple_two TEXT NOT NULL DEFAULT 'Mempelai 2';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS event_date TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS event_time TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS venue TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS address TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS story TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS hero_image TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS music_url TEXT NOT NULL DEFAULT '';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS theme TEXT NOT NULL DEFAULT 'luxury';
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS published BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS gallery JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS wedding_settings JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.wedding_invitations ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
CREATE TABLE IF NOT EXISTS public.wedding_rsvps (
 id BIGSERIAL PRIMARY KEY, invitation_slug TEXT NOT NULL REFERENCES public.wedding_invitations(slug) ON DELETE CASCADE,
 guest_name TEXT NOT NULL, attendance TEXT NOT NULL, guest_count INTEGER NOT NULL DEFAULT 1,
 message TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS wedding_rsvps_slug_idx ON public.wedding_rsvps(invitation_slug);
